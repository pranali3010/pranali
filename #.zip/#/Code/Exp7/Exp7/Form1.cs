﻿using System; 
using System.Collections.Generic; 
using System.ComponentModel; 
using System.Data; 
using System.Drawing; 
using System.Linq; 
using System.Text; 
using System.Windows.Forms; 
using System.Data.OleDb; 
namespace Exp7 { 
 public partial class Form1 : Form { 
 OleDbConnection cn; 
 OleDbCommand co; 
 OleDbDataReader dr; 
 public Form1() { 
 InitializeComponent(); 
 } 
 private void button1_Click(object sender, EventArgs e) { 
 try { 
cn = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\MOHSEEN ATTAR\Desktop\database7.accdb");
 cn.Open(); 
 co = cn.CreateCommand(); 
co.CommandText = "SELECT student.rno, student.sname, course.cname, course.cfees, studentfees.pfees, studentfees.rfees FROM (course INNER JOIN student ON course.cno = student.cno) INNER JOIN studentfees ON student.rno = studentfees.rno;"; 
 co.Parameters.AddWithValue("@rno", textBox1.Text); 
 dr = co.ExecuteReader(); 
 if (dr.HasRows) { 
 dr.Read(); 
 textBox2.Text = dr[1].ToString(); 
 textBox3.Text = dr[2].ToString(); 
 textBox4.Text = dr[3].ToString(); 
 textBox5.Text = dr[4].ToString(); 
 textBox6.Text = dr[5].ToString(); 
 dr.Close(); 
 } 
 else { 
 MessageBox.Show("No data found", "Error", MessageBoxButtons.OK, 
MessageBoxIcon.Information); 
 textBox1.Clear(); 
 textBox2.Clear(); 
 textBox3.Clear(); 
 textBox4.Clear(); 
 textBox5.Clear(); 
 textBox6.Clear(); 
 textBox1.Focus(); 
 } 
 } 
 catch (Exception ex) { 
 MessageBox.Show("An error occured : " + ex.Message, "Error", MessageBoxButtons.OK, 
MessageBoxIcon.Information); 
 } 
 finally { 
 dr.Close(); 
 cn.Close(); 
 } 
 } 
 private void button2_Click(object sender, EventArgs e) { 
 groupBox1.Enabled = true; 
 } 
 private void button3_Click(object sender, EventArgs e) { 
 try { 
 using (OleDbConnection connection = new OleDbConnection()) { 
 connection.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\MOHSEEN ATTAR\Desktop\database7.accdb"; 
 connection.Open(); 
 int recno = int.Parse(textBox7.Text); 
 DateTime recdate = DateTime.Parse(textBox8.Text); 
 int recamt = int.Parse(textBox9.Text); 
 int rno = int.Parse(textBox1.Text); 
 
 int totalFees = int.Parse(textBox4.Text); 
 int oldPaid = int.Parse(textBox5.Text); 
 if (oldPaid >= totalFees) 
 { 
 MessageBox.Show("Fees already fully paid."); 
 return; 
 } 
 int newPaid = oldPaid + recamt; 
 int remFees = totalFees - newPaid; 
 
 string insertQuery = "INSERT INTO studentfees (recno, recdate, rno, recamt, pfees, rfees) VALUES(?, ?, ?, ?, ?, ?)"; 
 using (OleDbCommand command = new OleDbCommand(insertQuery, connection)) { 
 command.Parameters.AddWithValue("?", recno); 
 command.Parameters.AddWithValue("?", recdate); 
 command.Parameters.AddWithValue("?", rno); 
 command.Parameters.AddWithValue("?", recamt); 
 command.Parameters.AddWithValue("?", newPaid); 
 command.Parameters.AddWithValue("?", remFees); 
 int result = command.ExecuteNonQuery(); 
 if (result > 0) { 
 MessageBox.Show("Fees Paid Successfully!"); 
 textBox5.Text = newPaid.ToString(); 
 textBox6.Text = remFees.ToString(); 
 textBox7.Clear(); 
 textBox8.Clear(); 
 textBox9.Clear(); 
 } 
 else { 
 MessageBox.Show("Insertion failed"); 
 } 
 } 
 } 
 } 
 catch (Exception ex) { 
 MessageBox.Show("An error occurred: " + ex.Message); 
 } 
 }

 private void button2_Click_1(object sender, EventArgs e)
 {
     groupBox1.Enabled = true; 
 }

 private void button3_Click_1(object sender, EventArgs e)
 {
     try
     {
         using (OleDbConnection connection = new OleDbConnection())
         {
             connection.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\MOHSEEN ATTAR\Desktop\database7.accdb";
             connection.Open();
             int recno = int.Parse(textBox7.Text);
             DateTime recdate = DateTime.Parse(textBox8.Text);
             int recamt = int.Parse(textBox9.Text);
             int rno = int.Parse(textBox1.Text);

             int totalFees = int.Parse(textBox4.Text);
             int oldPaid = int.Parse(textBox5.Text);
             if (oldPaid >= totalFees)
             {
                 MessageBox.Show("Fees already fully paid.");
                 return;
             }
             int newPaid = oldPaid + recamt;
             int remFees = totalFees - newPaid;

             string insertQuery = "INSERT INTO studentfees (recno, recdate, rno, recamt, pfees, rfees) VALUES(?, ?, ?, ?, ?, ?)";
             using (OleDbCommand command = new OleDbCommand(insertQuery, connection))
             {
                 command.Parameters.AddWithValue("?", recno);
                 command.Parameters.AddWithValue("?", recdate);
                 command.Parameters.AddWithValue("?", rno);
                 command.Parameters.AddWithValue("?", recamt);
                 command.Parameters.AddWithValue("?", newPaid);
                 command.Parameters.AddWithValue("?", remFees);
                 int result = command.ExecuteNonQuery();
                 if (result > 0)
                 {
                     MessageBox.Show("Fees Paid Successfully!");
                     textBox5.Text = newPaid.ToString();
                     textBox6.Text = remFees.ToString();
                     textBox7.Clear();
                     textBox8.Clear();
                     textBox9.Clear();
                 }
                 else
                 {
                     MessageBox.Show("Insertion failed");
                 }
             }
         }
     }
     catch (Exception ex)
     {
         MessageBox.Show("An error occurred: " + ex.Message);
     } 
 } 
 } 
}