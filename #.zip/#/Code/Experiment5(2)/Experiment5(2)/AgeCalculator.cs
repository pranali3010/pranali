﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Experiment5_2_
{
    class AgeCalculator
    {
        private string age = ""; 
        private DateTime dob; 
        private int bd, bm, by; 

        public DateTime DOB { 
            set { 
                dob = value; 
            } 
        } 
 
        public string AGE { 
            get {
                CalculateAge();
                return age; 
            } 
        } 
 
        private void CalculateAge() { 
            int cd = DateTime.Today.Day; 
            int cm = DateTime.Today.Month; 
            int cy = DateTime.Today.Year; 

            bd = dob.Day; 
            bm = dob.Month; 
            by = dob.Year; 
 
            int ad = cd - bd; 
            int am = cm - bm; 
            int ay = cy - by; 
 
            if (ad < 0) { 
                am -= 1; 
                ad += 30; 
            } 

            if (am < 0) { 
                ay -= 1; 
                am += 12; 
            } 
            age = "Age is : " + ay.ToString() + " Years " + am.ToString() + " Months " + ad.ToString() + " Days "; 
        }
    }
}
