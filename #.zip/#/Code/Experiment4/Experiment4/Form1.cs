﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Experiment4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Activated(object sender, EventArgs e)
        {
            comboBox1.Items.Clear();
            comboBox2.Items.Clear();
            comboBox3.Items.Clear();

            for (int n = 1; n <= 31; n++)
                comboBox1.Items.Add(n);
            for (int n = 1; n <= 12; n++)
                comboBox2.Items.Add(n);

            for (int n = 2025; n >= 1945; n--)
                comboBox3.Items.Add(n);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int bd, bm, by, cd, cm, cy, ad, am, ay;
            bd = Convert.ToInt32(comboBox1.SelectedItem);
            bm = Convert.ToInt32(comboBox2.SelectedItem);
            by = Convert.ToInt32(comboBox3.SelectedItem);

            cd = DateTime.Today.Day;
            cm = DateTime.Today.Month;
            cy = DateTime.Today.Year;

            ad = cd - bd;
            am = cm - bm;
            ay = cy - by;

            if (ad < 0)
            {
                am -= 1;
                ad += 30;
            }
            if (am < 0)
            {
                ay -= 1;
                am += 12;
            }
            label4.Text = " Age is " + ay.ToString() + " Years " + am.ToString() + " Months " + ad.ToString() + " Days ";
        }

        
    }
}
