﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
namespace Exp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            int n1, n2, ans = 0;
            Button b = (Button)sender;
            n1 = Convert.ToInt16(textBox1.Text);
            n2 = Convert.ToInt16(textBox2.Text);
            switch (b.Text)
            {
                case "Add":
                    ans = n1 + n2;
                    break;
                case "Difference":
                    ans = n1 - n2;
                    if (ans < 0)
                        ans *= -1;
                    break;
                case "Multiply":
                    ans = n1 * n2;
                    break;
                case "Divide":
                    ans = n1 / n2;
                    break;
            }
            textBox3.Text = ans.ToString();
        }
    }
}
