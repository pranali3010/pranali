﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace Exp11
{
    public partial class Form1 : Form
    {
        string connStr = "server=localhost;user=root;database=stud;";
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(connStr))
                {
                    conn.Open();
                    MySqlCommand cmd = new MySqlCommand("SELECT Rno FROM studentfees", conn);
                    MySqlDataReader dr = cmd.ExecuteReader();
                    while (dr.Read())
                    {
                        comboBox1.Items.Add(dr["Rno"].ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading Rno values: " + ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
             int rno = 0; 
            if (!string.IsNullOrWhiteSpace(comboBox1.Text)) 
                int.TryParse(comboBox1.Text, out rno); 
            else if (!string.IsNullOrWhiteSpace(textBox1.Text)) 
                int.TryParse(textBox1.Text, out rno); 
 
            if (rno == 0) 
            { 
                MessageBox.Show("Please enter or select a valid Roll Number."); 
                return; 
            } 
            try 
            { 
                using (MySqlConnection conn = new MySqlConnection(connStr)) 
                { 
                    conn.Open(); 
                    MySqlCommand cmd = new MySqlCommand("GetStudentFeeDetails", conn); 
                    cmd.CommandType = CommandType.StoredProcedure; 
                    cmd.Parameters.AddWithValue("@input_rno", rno); 
 
                    MySqlDataAdapter da = new MySqlDataAdapter(cmd); 
                    DataTable dt = new DataTable(); 
                    da.Fill(dt); 
 
                    if (dt.Rows.Count > 0) 
                    { 
                        DataRow row = dt.Rows[0]; 
 
                        textBox1.Text = row["Rno"].ToString(); 
                        textBox2.Text = row["Sname"].ToString(); 
                        textBox3.Text = row["CName"].ToString(); 
                        textBox4.Text = row["CFees"].ToString(); 
                        textBox5.Text = row["PFees"].ToString(); 
                        textBox6.Text = row["RemainingFees"].ToString(); 
 
                        dataGridView1.DataSource = dt; 
                    } 
                    else 
                    { 
                        MessageBox.Show("Record not found."); 
                    } 
                } 
            } 
            catch (Exception ex) 
            { 
                MessageBox.Show("Error fetching data: " + ex.Message); 
            } 
        } 
    }
        }

      

       
    

