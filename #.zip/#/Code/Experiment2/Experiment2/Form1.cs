﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Experiment2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int  ans = 0, n1, n2;
            n1 = Convert.ToInt16(textBox1.Text);
            n2 = Convert.ToInt16(textBox2.Text);

            switch (comboBox1.SelectedItem.ToString())
            {
                case "Add":
                    ans = n1 + n2;
                    break;

                case "Subtract":
                    ans = n1 - n2;
                    break;

                case "Multiply":
                    ans = n1 * n2;
                    break;

                case "Divide":
                    ans = n1 / n2;
                    break;
            }
            textBox3.Text = ans.ToString();
        }
        
    }
}
