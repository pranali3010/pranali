﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Exp9
{
    public partial class Form1 : Form
    {
        string connectionString = @"Data Source=MOHSEEN\SQLEXPRESS01;Initial Catalog=StudDetails;Integrated Security=True";
        public Form1()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection cn = new SqlConnection(connectionString))
                {
                    cn.Open();
                    SqlCommand cmd = new SqlCommand("GetRemainingFees", cn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@rno", int.Parse(textBox1.Text));
                    SqlDataReader dr = cmd.ExecuteReader();
                    if (dr.Read())
                    {
                        textBox2.Text = dr["sname"].ToString();
                        textBox3.Text = dr["cfees"].ToString();
                        textBox4.Text = dr["pfees"].ToString();
                        textBox5.Text = dr["rfees"].ToString();
                    }
                    else
                    {
                        MessageBox.Show("Record not found.");
                    }
                    dr.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}