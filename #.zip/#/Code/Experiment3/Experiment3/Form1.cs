﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace Experiment3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string pattern = @"^[A-Za-z.\s]*$"; 
            if (!Regex.IsMatch(textBox1.Text, pattern)) 
            { 
                MessageBox.Show("Only letters, spaces, and dots are allowed in the name.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning); 
                textBox1.Text = Regex.Replace(textBox1.Text, @"[^A-Za-z.\s]", ""); 
                textBox1.SelectionStart = textBox1.Text.Length; 
            } 
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\b')
                return;
            if (e.KeyChar == '\r')
                SendKeys.Send("{TAB}");
            if (!((e.KeyChar >= '0') & (e.KeyChar <= '9')))
                e.Handled = true;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "" || textBox5.Text == "" || textBox6.Text == "")
            {
                MessageBox.Show("Please enter marks for all subjects.");
                return;
            }

            int marathi = int.Parse(textBox2.Text);
            int hindi = int.Parse(textBox3.Text);
            int english = int.Parse(textBox4.Text);
            int maths = int.Parse(textBox5.Text);
            int science = int.Parse(textBox6.Text);

            if (!IsValid(marathi) || !IsValid(hindi) || !IsValid(english) || !IsValid(maths) || !IsValid(science))
            {
                MessageBox.Show("Marks must be between 0 and 100.");
                return;
            }

            int total = marathi + hindi + english + maths + science;
            float percentage = total / 5f;

            textBox7.Text = total.ToString();
            textBox8.Text = percentage.ToString("0.00");
        }

        private bool IsValid(int marks)
        {
            return marks >= 0 && marks <= 100;
        }

    }
}
