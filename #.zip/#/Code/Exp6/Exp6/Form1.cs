﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Exp6
{
    public partial class Form1 : Form
    {
        OleDbConnection cn;
        OleDbCommand co;
        OleDbDataReader dr;
        public Form1()
        {
            InitializeComponent();
        }
        private void textBox2_TextChanged(object sender, EventArgs e)
        {
        }
        private void Form1_Load(object sender, EventArgs e)
        {
        }
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                cn = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source= C:\Users\MOHSEEN ATTAR\Desktop\database6.accdb");
                cn.Open();
                co = cn.CreateCommand();
                co.CommandText = "select * from course where cno = " + textBox1.Text;
                dr = co.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    textBox2.Text = dr[1].ToString();
                    textBox3.Text = dr[2].ToString();
                    textBox4.Text = dr[3].ToString();
                }
                else
                {
                    MessageBox.Show("No data found", "Error", MessageBoxButtons.OK,
                   MessageBoxIcon.Information);
                    textBox1.Clear();
                    textBox1.Focus();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occured : " + ex.Message, "Error", MessageBoxButtons.OK,
               MessageBoxIcon.Information);
            }
            finally
            {
                dr.Close();
                cn.Close();
            }
        }
    }
}