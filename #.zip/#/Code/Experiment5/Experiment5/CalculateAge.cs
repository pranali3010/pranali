﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Experiment5
{
    class CalculateAge
    {
        public int Years { get; private set; } 
        public int Months { get; private set; } 
        public int Days { get; private set; } 
 
        public CalculateAge(DateTime birthDate, DateTime currentDate) 
        { 
            int bd = birthDate.Day; 
            int bm = birthDate.Month; 
            int by = birthDate.Year; 

            int cd = currentDate.Day; 
            int cm = currentDate.Month; 
            int cy = currentDate.Year;
 
            Days = cd - bd; 
            Months = cm - bm; 
            Years = cy - by; 

            if (Days < 0) { 
            Months -= 1; 
            Days += 30; // Approximate month length 
            } 
 
            if (Months < 0) { 
            Years -= 1; 
            Months += 12; 
            } 
        } 
    }
}
