﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Experiment5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DateTime birthDate = monthCalendar1.SelectionStart; 
            DateTime currentDate = DateTime.Today; 
 
            CalculateAge age = new CalculateAge(birthDate, currentDate); 
            label1.Text = "Age is: " + age.Years + " Years " + age.Months + " Months " + age.Days + " Days"; 
        }
    }
}
